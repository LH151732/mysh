#!/bin/bash

PYTHON_SCRIPT="/home/mysh.py"
INPUT_DIR="io_files"
LOG_FILE="test_log.txt"

cleanup() {
    rm -f test_output.txt
    rm -f $LOG_FILE
}
trap cleanup EXIT

log() {
    echo "$1" | tee -a $LOG_FILE
}

test_from_file() {
    local test_name="$1"
    local input_file="$2"
    local expected_output_file="$3"

    log "Running test: $test_name"
    log "Input File: $input_file"
    log "Expected Output File: $expected_output_file"

    start_time=$(date +%s.%N)

    # Execute the script using input redirection from the .in file
    python3 $PYTHON_SCRIPT < "$input_file" > test_output.txt 2>&1
    local status=$?
    local end_time=$(date +%s.%N)
    local duration=$(echo "$end_time - $start_time" | bc)

    if [ $status -ne 0 ]; then
        log "Test failed: $test_name - Command failed with status $status"
        log "Exit Status: $status"
        log "Actual Output:"
        cat test_output.txt | tee -a $LOG_FILE
        return 1
    fi

    # Compare the actual output with the expected output
    if ! diff -q test_output.txt "$expected_output_file" > /dev/null; then
        log "Test failed: $test_name - Output does not match expected"
        log "Expected Output:"
        cat "$expected_output_file" | tee -a $LOG_FILE
        log "Actual Output:"
        cat test_output.txt | tee -a $LOG_FILE
        return 1
    fi

    log "Test passed: $test_name"
    log "Duration: ${duration}s"
    return 0
}

# Define test cases using input and output files
log "Starting tests at $(date)"

for input_file in $INPUT_DIR/*.in; do
    base_name=$(basename "$input_file" .in)
    expected_output_file="$INPUT_DIR/$base_name.out"
    
    if [ -f "$expected_output_file" ]; then
        test_from_file "Test $base_name" "$input_file" "$expected_output_file"
    else
        log "Missing expected output file for $input_file"
    fi
done

log "Completed tests at $(date)"

